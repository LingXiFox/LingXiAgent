from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json
root=Path(__file__).parent
page='''<!doctype html><html><head><meta charset="utf-8"><title>LingXiAgent Layered Browser Test</title><style>body{font:20px system-ui;padding:24px;background:#18212e;color:white}input,button{font:18px system-ui;padding:10px;margin:8px}a{color:#7dd3fc}</style></head><body><h1>LingXiAgent Layered Browser Test</h1><p id="id"></p><label>Message <input id="message"></label><button id="submit">Submit</button><p id="result">No submission</p><button id="popup">Open popup</button><p id="popup-status">Not requested</p><script>window.poc={documentId:crypto.randomUUID(),popupCount:0};id.textContent='Document '+poc.documentId;submit.onclick=e=>{result.textContent=message.value;poc.trusted=e.isTrusted};popup.onclick=e=>{poc.popupCount++;poc.popupTrusted=e.isTrusted;let child=window.open('/popup','popup-'+poc.popupCount,'width=600,height=450');poc.returned=!!child;document.getElementById('popup-status').textContent='Requested '+poc.popupCount+'; returned '+!!child;};</script></body></html>'''
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.end_headers();self.wfile.write(page.encode())
 def log_message(self,*args): pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
(root/'server.json').write_text(json.dumps({'url':f'http://127.0.0.1:{server.server_port}'}));print('Fixture port',server.server_port,flush=True);server.serve_forever()
