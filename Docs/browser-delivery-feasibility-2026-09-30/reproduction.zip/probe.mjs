import { chromium } from '/Volumes/Development/Projects/projects/LingXiAgent/Sidecars/browser-host/node_modules/playwright/index.mjs';
import http from 'node:http';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const base='/private/tmp/lingxi-browser-feasibility-20260930';
const result={tests:{},versions:{playwright:'1.63.0',chrome:'153.0.8010.53'}};
const save=()=>fs.writeFileSync(`${base}/results.json`,JSON.stringify(result,null,2));
const html=`<!doctype html><title>LingXiAgent Delivery Validation</title><style>body{background:#162130;color:white;font:24px system-ui;margin:30px}input,button{font:24px system-ui;margin:10px;padding:10px}</style><h1>LingXiAgent Delivery Validation</h1><p id="document"></p><label>Message <input id="message"></label><button id="submit">Submit</button><p id="result">Ready</p><button id="popup">Open popup</button><script>window.probe={documentId:crypto.randomUUID()};document.querySelector('#document').textContent=probe.documentId;document.querySelector('#submit').onclick=e=>{probe.trusted=e.isTrusted;document.querySelector('#result').textContent=document.querySelector('#message').value};document.querySelector('#popup').onclick=()=>window.open('/popup','_blank','width=700,height=500');</script>`;
const server=http.createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(html)});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin=`http://127.0.0.1:${server.address().port}`;
let context;
try {
 context=await chromium.launchPersistentContext(`${base}/profile`,{channel:'chrome',headless:false,chromiumSandbox:true,args:['--use-mock-keychain'],viewport:{width:1000,height:700}});
 const page=context.pages()[0];await page.goto(origin);
 result.documentId=await page.evaluate(()=>probe.documentId);
 for(let i=0;i<3;i++){
  const wait=page.waitForEvent('popup',{timeout:5000});
  await page.locator('#popup').click();const popup=await wait;
  await popup.waitForLoadState();await popup.locator('#message').fill(`Popup ${i}`);await popup.locator('#submit').click();
  const state=await popup.evaluate(()=>({...probe,text:document.querySelector('#result').textContent}));
  assert.equal(state.text,`Popup ${i}`);assert.equal(state.trusted,true);await popup.close();
 }
 result.tests.automaticPopupThreeCycles='PASS';
 await page.locator('#message').fill('Agent first');await page.locator('#submit').click();
 assert.equal(await page.locator('#result').textContent(),'Agent first');
 await page.bringToFront();
 result.tests.agentInput='PASS';result.nativeReady={url:origin,title:await page.title(),expected:'Native takeover'};save();
 console.log('NATIVE_READY',origin,flush());
 await page.waitForFunction(()=>document.querySelector('#result').textContent==='Native takeover',null,{timeout:120000});
 const native=await page.evaluate(()=>({...probe,text:document.querySelector('#result').textContent}));
 assert.equal(native.documentId,result.documentId);assert.equal(native.trusted,true);
 result.native=native;result.tests.nativeTakeoverSameDocument='PASS';
 await page.locator('#message').fill('Agent resumed');await page.locator('#submit').click();
 assert.equal(await page.locator('#result').textContent(),'Agent resumed');assert.equal(await page.evaluate(()=>probe.documentId),result.documentId);
 result.tests.agentResumeSameDocument='PASS';
 await page.screenshot({path:`${base}/shared-page.png`});
 await context.close();context=null;result.tests.gracefulBrowserClose='PASS';
} catch(e){result.error=e.stack;process.exitCode=1;} finally {
 if(context)await context.close();await new Promise(resolve=>server.close(resolve));save();console.log(JSON.stringify(result));
}
function flush(){return '';}
