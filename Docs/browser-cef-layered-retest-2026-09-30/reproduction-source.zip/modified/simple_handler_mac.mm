// Copyright (c) 2013 The Chromium Embedded Framework Authors. All rights
// reserved. Use of this source code is governed by a BSD-style license that
// can be found in the LICENSE file.

#include "tests/cefsimple/simple_handler.h"

#import <Cocoa/Cocoa.h>

#include "include/cef_browser.h"

namespace {

NSWindow* GetNSWindowForBrowser(CefRefPtr<CefBrowser> browser) {
  NSView* view =
      CAST_CEF_WINDOW_HANDLE_TO_NSVIEW(browser->GetHost()->GetWindowHandle());
  return [view window];
}

}  // namespace

void SimpleHandler::PlatformTitleChange(CefRefPtr<CefBrowser> browser,
                                        const CefString& title) {
  NSWindow* window = GetNSWindowForBrowser(browser);
  std::string titleStr(title);
  NSString* str = [NSString stringWithUTF8String:titleStr.c_str()];
  [window setTitle:str];
}

void SimpleHandler::PlatformShowWindow(CefRefPtr<CefBrowser> browser) {
  NSWindow* window = GetNSWindowForBrowser(browser);
  [window makeKeyAndOrderFront:window];
}

extern "C" void* LingXiCreateSwiftHost(void* container);
@interface LingXiHostDelegate : NSObject <NSWindowDelegate>
@end
@implementation LingXiHostDelegate
- (void)windowWillClose:(NSNotification*)notification {
  NSWindow* window = notification.object;
  window.contentView = nil;
  fprintf(stderr, "OBS SwiftUI main content released\n");
}
@end
void* LingXiCreateEmbeddedParent() {
  static LingXiHostDelegate* delegate = [LingXiHostDelegate new];
  NSView* container = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 1000, 700)];
  NSView* host = CFBridgingRelease(LingXiCreateSwiftHost((__bridge void*)container));
  NSWindow* window = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, 1000, 700)
      styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskResizable | NSWindowStyleMaskMiniaturizable
      backing:NSBackingStoreBuffered defer:NO];
  window.releasedWhenClosed = NO;
  window.delegate = delegate;
  window.contentView = host;
  [window center];
  [window makeKeyAndOrderFront:nil];
  [host layoutSubtreeIfNeeded];
  fprintf(stderr, "OBS SwiftUI container %.0fx%.0f\n", container.bounds.size.width, container.bounds.size.height);
  return (__bridge void*)container;
}
