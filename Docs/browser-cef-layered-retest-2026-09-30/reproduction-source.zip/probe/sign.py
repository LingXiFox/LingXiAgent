from pathlib import Path
import subprocess
b=Path('/tmp/lingxi-cef-layered-retest-20260930');a=b/'build/tests/cefsimple/Release/cefsimple.app';f=a/'Contents/Frameworks/Chromium Embedded Framework.framework'
for p in [f/'Versions/A/A', f/'Versions/A/Resources/Resources', f/'Versions/A/Libraries/Libraries']:
 if p.is_symlink() and not p.exists(): p.unlink()
for p in list((f/'Versions/A/Libraries').glob('*.dylib'))+[f]+list((a/'Contents/Frameworks').glob('*.app'))+list((a/'Contents/Frameworks').glob('*.dylib'))+[a]:
 subprocess.run(['codesign','--force','--sign','-','--timestamp=none',str(p)],check=True,capture_output=True)
subprocess.run(['codesign','--verify','--deep','--strict',str(a)],check=True)
print('Signature verified')
