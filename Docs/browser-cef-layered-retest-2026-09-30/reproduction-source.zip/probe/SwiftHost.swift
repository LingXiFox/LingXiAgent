import AppKit
import SwiftUI
struct BrowserContainer: NSViewRepresentable {
    let container: NSView
    func makeNSView(context: Context) -> NSView { container }
    func updateNSView(_ view: NSView, context: Context) {}
}
@_cdecl("LingXiCreateSwiftHost")
public func createSwiftHost(_ pointer: UnsafeMutableRawPointer) -> UnsafeMutableRawPointer {
    let container = Unmanaged<NSView>.fromOpaque(pointer).takeUnretainedValue()
    let host = NSHostingView(rootView: BrowserContainer(container: container))
    host.frame = NSRect(x: 0, y: 0, width: 1000, height: 700)
    return Unmanaged.passRetained(host).toOpaque()
}
