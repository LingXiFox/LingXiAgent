import {chromium} from '/Volumes/Development/Projects/projects/LingXiAgent/Sidecars/browser-host/node_modules/playwright/index.mjs';
import fs from 'node:fs';
const base='/private/tmp/lingxi-cef-layered-retest-20260930';
const phase=process.argv[2];
const port=fs.readFileSync(`${base}/${phase}-profile/DevToolsActivePort`,'utf8').split('\n')[0];
const out={phase,events:[]};
const save=()=>fs.writeFileSync(`${base}/${phase}-playwright.json`,JSON.stringify(out,null,2));
const deadline=setTimeout(()=>{out.deadline='30s overall';save();process.exit(2)},30000);
let browser;
try {
 browser=await chromium.connectOverCDP(`http://127.0.0.1:${port}`,{timeout:10000});
 const context=browser.contexts()[0];const page=context.pages().find(p=>p.url()==='http://127.0.0.1:65383/');
 if(!page)throw new Error('Main fixture page not found');
 out.mainBefore=await page.evaluate(()=>({...window.poc}));
 await page.locator('#message').fill('Playwright 同页测试');await page.locator('#submit').click();
 out.mainAfter=await page.evaluate(()=>({...window.poc,result:document.querySelector('#result').textContent}));
 if(out.mainAfter.result!=='Playwright 同页测试'||!out.mainAfter.trusted)throw new Error('Input/trusted click check failed');
 context.on('page',p=>out.events.push({event:'page',url:p.url()}));
 const popupWait=page.waitForEvent('popup',{timeout:6000}).then(p=>({page:p})).catch(e=>({error:e.message}));
 await page.locator('#popup').click({timeout:6000});
 const popup=await popupWait;
 if(popup.error){out.popupError=popup.error;}else{
  await popup.page.waitForLoadState('domcontentloaded',{timeout:6000});
  out.popup=await popup.page.evaluate(()=>({...window.poc,url:location.href}));
  await popup.page.locator('#message').fill('Automated popup');await popup.page.locator('#submit').click();
  out.popupAfter=await popup.page.evaluate(()=>({...window.poc,result:document.querySelector('#result').textContent}));
  if(out.popupAfter.result!=='Automated popup'||!out.popupAfter.trusted)throw new Error('Popup input/trusted check failed');
  await popup.page.screenshot({path:`${base}/${phase}-popup.png`});
 }
 out.pages=context.pages().map(p=>p.url());
} catch(e){out.error=e.stack;}
save();
if(browser)await browser.close();
clearTimeout(deadline);
console.log(JSON.stringify(out));
