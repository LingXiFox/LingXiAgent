from pathlib import Path
import subprocess,json,sys,time
base=Path('/private/tmp/lingxi-cef-layered-retest-20260930')
phase=sys.argv[1]
app=Path(sys.argv[2]).resolve()
profile=base/(phase+'-profile');profile.mkdir(exist_ok=True)
args=[str(app/'Contents/MacOS/cefsimple'),'--url=http://127.0.0.1:65383',*sys.argv[3:],'--use-mock-keychain','--remote-debugging-port=0','--root-cache-path='+str(profile),'--cache-path='+str(profile)]
log=open(base/(phase+'.log'),'w')
import os
env=os.environ.copy();env['LINGXI_TEST_PROFILE']=str(profile)
p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,env=env)
(base/(phase+'-launch.json')).write_text(json.dumps({'pid':p.pid,'argv':args},indent=2))
print('Started',phase,p.pid,flush=True)
code=p.wait()
(base/(phase+'-exit.json')).write_text(json.dumps({'exitCode':code,'time':time.time()}))
print('Exited',phase,code,flush=True)
